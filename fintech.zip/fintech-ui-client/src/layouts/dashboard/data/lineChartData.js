export const lineChartDataDashboard = [
  // {
  //   name: "Mobile apps",
  //   data: [500, 250, 300, 220, 500, 250, 300, 230, 300, 350, 250, 400],
  // },
  // {
  //   name: "Websites",
  //   data: [200, 230, 300, 350, 370, 420, 550, 350, 400, 500, 330, 550],
  // },
  {
    name: "Exprenses",
    data: [1500, 11250, 5300, 220],
  },
  {
    name: "Income",
    data: [12000, 5000, 12300, 5350],
  },
];
