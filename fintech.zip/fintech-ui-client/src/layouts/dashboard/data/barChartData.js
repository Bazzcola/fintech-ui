export const barChartDataDashboard = [
  {
    name: "Sales",
    data: [50, 150, 25, 125, 150, 100, 50, 50, 200],
  },
];
